import Starter from "./form.jsx";
function App() {
  return (
    <div className="container">
      <h2>
        <Starter />
      </h2>
    </div>
  );
}

export default App;
